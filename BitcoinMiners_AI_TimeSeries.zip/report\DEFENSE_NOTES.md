# Defence notes — *Did Bitcoin miners leave Bitcoin for AI?*

How to use: for each section, (1) what was done, (2) why, (3) how to read the key figure/table, (4) likely examiner questions with short answers. Every number comes from an executed notebook or a file in `results/`. Practise the answers **out loud**, in your own words.

**The answer in 30 seconds.** After early 2025 (pivot 2025-01-22, detected by break tests), the AI converts (IREN, CIFR, WULF) gained a **same-day exposure to NVIDIA that adds to — not replaces — their Bitcoin link**: NVDA shock response ×2.2, |r| correlation with NVDA 0.06 → 0.31, DCC 0.33 → 0.42, the correlation lines cross 40% of post-pivot days. None of this appears for the pure miners (control). There is no long-run Bitcoin link to lose (never cointegrated) and no predictive (Granger) link. For forecasting, nothing significantly beats the random walk.

---

## 1. Data (notebook 01, `data/DATA_DICTIONARY.md`)

**Done.** 8 tickers from Yahoo Finance (yfinance 1.8.0), `Adj Close`, frozen in `data/raw/`. 1,225 US trading days, 2021-12-14 → 2026-10-30. Equal-weighted indices CONVERTS and PURE built from log returns, rebased to 100. 90/10 chronological split: train 1,102 days (→ 2026-05-06), test 123 days.

**Why.** Stock trading days only (BTC sampled on them) because joint models need simultaneous observations; filling weekends would create fake zero returns. Indices reduce single-stock noise. Raw files frozen because Yahoo revises adjusted history.

**Key figure.** `fig_02_02_indices_vs_references`: the two miner groups move together until mid-2025, then CONVERTS takes off and PURE stagnates.

**Questions.**
- *Why only 4.88 years, not 5?* Before 2021-12-14 the Yahoo histories of WULF (IKONICS) and CIFR (a SPAC) belong to other companies, and IREN listed in Nov 2021. Replacing them would weaken the research question; 1,225 observations are enough for every method.
- *Why Adj Close?* It absorbs splits (NVDA 10:1 in 2024) and dividends, so returns are total returns with no artificial jumps.
- *What about BTC's closing time?* BTC "closes" at midnight UTC, 3–4 h after stocks. It matters for same-day effects (Cholesky order) and is stated as a limitation.

## 2. EDA, stationarity, pivot date (notebook 02)

**Done.** ACF/PACF on log prices and returns, STL (s = 5 and 252), outliers (Hampel + rolling IQR), ADF + KPSS, rolling correlation and rolling Engle-Granger, Chow scan and Bai-Perron to find the pivot.

**Results.** d = 1 for all series. No seasonality (F_S ≤ 0.03; weekday ANOVA p 0.26–0.61). Outliers kept (real events: FTX, DeepSeek, the Google deal). Pivot 2025-01-22: Chow sup-F 8.63, PURE not breaking there (p = 0.15), robust without the DeepSeek day (F = 6.52, p = 0.0002). β_NVDA of CONVERTS 0.31 → 0.87, β_BTC 1.03 → 0.71.

**Key table.** `02_stationarity_adf_kpss.csv`: log prices ADF p 0.08–0.61 and KPSS p ≤ 0.01 → non-stationary; returns ADF p < 0.001 and KPSS p ≥ 0.10 → stationary.

**Questions.**
- *Why ADF AND KPSS?* Opposite null hypotheses (ADF: unit root; KPSS: stationarity). When they agree the conclusion is firm; when they disagree (WULF, RIOT in level) the case is flagged as ambiguous.
- *Why not take the pivot date from the news?* That would impose the answer. The date is searched for in the data, and PURE serves as a control: a break that also hits PURE is a "miners in general" break, not an AI pivot.
- *Are the Chow p-values valid?* No, they are optimistic, because the date was chosen by scanning. The correct threshold would be Andrews' sup-F critical value. This is stated; the evidence is called "moderate".

## 3. ARIMA / SARIMA (notebook 03 + `03_arima.Rmd`)

**Done.** Manual identification, full grid, auto_arima / auto.arima, seasonal tests, full residual diagnostics, rolling-origin forecasts h = 1..10.

**Results.** ARIMA(0,1,0) without drift = random walk (BIC, manual and auto agree; ΔAIC to (0,1,1) only 0.37, MA coefficient 0.047 not significant). No SARIMA (D = 0, seasonal LR p ≥ 0.07). Residuals: no autocorrelation, non-normal, **no ARCH for CONVERTS (p = 0.61)**, ARCH for PURE (p = 0.006). RMSE h5 / h10: 28.77 / 36.10.

**Questions.**
- *Isn't a random walk a "non-model"?* It is the model the diagnostics choose: returns have no autocorrelation. It is also the benchmark every other model must beat.
- *Why did auto_arima give (5,2,1)?* Its internal KPSS test asked for d = 2: over-differencing, rejected because Phase 2 showed returns are stationary.
- *Why rolling origins?* One origin gives one error per horizon; rolling origins give 119 errors at h = 5, which makes RMSE and Diebold-Mariano meaningful. Parameters are fixed from the training sample, so no test information leaks.

## 4. VAR, Granger, IRF, Johansen, VECM (notebook 04 + `04_var_vecm.Rmd`)

**Done.** VAR on returns [BTC, NVDA, CONVERTS, PURE] on the full sample, pre- and post-pivot; Granger; Cholesky IRF; Johansen + Engle-Granger on log prices; VECM; robustness with other pivot dates.

**Results.** All criteria choose p = 0; VAR(1) used for Granger. No robust Granger causality (BTC → CONVERTS p = 0.55 / 0.77 / 0.091). **IRF h = 0: NVDA → CONVERTS 0.0105 → 0.0228 (×2.2, bands disjoint), NVDA → PURE unchanged.** BTC → both groups −21% / −25%. Cointegration only CONVERTS–NVDA, full and pre-pivot, borderline (R's urca critical value 17.95 vs statsmodels 15.49). VECM half-life 45–64 days.

**Key figure.** `fig_04_01_irf_pre_post`: the only response that jumps after the pivot is NVDA → CONVERTS.

**Questions.**
- *What does α in the VECM mean?* The share of yesterday's equilibrium gap corrected today. α_CONVERTS = −0.0108 → half-life ln(0.5)/ln(1+α) ≈ 64 trading days. Negative = CONVERTS moves back towards equilibrium.
- *Granger says nothing, so is there no link?* Granger tests whether yesterday predicts today. The link is same-day (prices absorb information within the day), which the h = 0 impulse response captures. Granger ≠ economic causality.
- *Why a VAR on returns and cointegration on prices?* A VAR on I(1) levels gives invalid tests; long-run relationships between I(1) prices are exactly what cointegration tests.
- *H1 was not supported — is that a problem?* No: it is an honest result. PURE–BTC is not cointegrated by Johansen (Engle-Granger p = 0.045 only on the full sample). The control is valid for the short run, not as an "anchored" long-run control.

## 5. ARCH / GARCH (notebook 05 + `05_garch.Rmd`)

**Done.** ARCH-LM on ARIMA and VAR residuals, GARCH-N / GARCH-t / GJR / EGARCH, standardised-residual diagnostics, conditional volatility with 6 press-checked events, pre/post comparison, volatility forecasts (QLIKE).

**Results.** GARCH(1,1)-t chosen. For CONVERTS α = 0.015 (n.s.), β = 0.954; BIC prefers constant variance. Standardised residuals clean (all p ≥ 0.22). EGARCH degenerate in Python, regular in rugarch → excluded. |r| correlation CONVERTS–NVDA 0.063 → 0.310 after the pivot (PURE 0.150 → 0.237).

**Questions.**
- *Why fit a GARCH on CONVERTS if ARCH-LM does not reject?* The brief requires it, and it is the target series; the result is reported honestly: the gain over a constant variance is small and constant variance forecasts as well.
- *Why does the index show no ARCH when IREN and WULF do?* Firm-specific volatility bursts happen on different dates and average out in a three-stock index.
- *Why QLIKE rather than MSE for volatility?* The true variance is unobserved; r² is a noisy proxy, and QLIKE ranks forecasts robustly under that noise (Patton 2011).

## 6. Deep learning (notebook 06, Python only)

**Done.** LSTM and GRU, windows 10/20/40, univariate vs exogenous inputs, 12-model grid, early stopping, 5-fold expanding walk-forward, ARIMA + LSTM hybrid, seed sensitivity. Direct multi-output (10 returns at once).

**Results.** All networks at the random-walk level (validation-loss ratio 0.995–0.9997). Walk-forward h5 ratio 0.996 (LSTM) / 1.007 (GRU). Test RMSE h5: hybrid 29.09, LSTM 29.53, GRU 30.13 vs rw 28.77.

**Questions.**
- *Why never k-fold?* It would train on the future and test on the past (leakage); time-series CV keeps the order and expands the window.
- *Why didn't deep learning work?* Returns are nearly unpredictable (no autocorrelation, VAR p = 0), signal-to-noise is tiny (≈ 6% daily vol vs ≈ 0.01% mean), and fewer than 900 windows for thousands of parameters.
- *Why is the hybrid built on ARIMA(0,1,1) and not the chosen (0,1,0)?* On (0,1,0), the residuals are the returns themselves, so the hybrid would equal the univariate LSTM.

## 7. Evaluation (notebook 07)

**Done.** Single table (8 models, MSE/RMSE/MAE/MAPE, coverage, interpretability, training time), Diebold-Mariano with HLN correction (`src/metrics.py`, unit-tested against R), top-3 forecast plot, recommendation.

**Key table.** `model_comparison.csv`: vecm_nvda 27.86 / 33.78, rw 28.77 / 36.10, … var1_post 30.41 / 41.71. `07_dm_tests.csv`: VECM vs rw p = 0.49 / 0.53.

**Questions.**
- *Why Diebold-Mariano and not just RMSE?* Two RMSEs on 119 noisy forecasts can differ by chance; DM tests whether the loss difference is larger than noise. Here the VECM's 3–6% gain is not significant.
- *Why the HLN correction?* The DM statistic is biased in small samples with h > 1 (overlapping errors); HLN rescales it and uses a Student-t.
- *Why MAPE on levels?* Returns are often near 0, so dividing by them makes MAPE explode; the index level stays between ≈ 115 and 345.
- *Which model would you use?* Random walk as the benchmark; VECM CONVERTS–NVDA as the interpretable model to monitor; no deep learning.

## 8. Extensions (notebook 07, `07_dcc.Rmd`)

**Key figure.** `fig_07_03_rolling_corr_crossing` ("the crossing lines"): after the pivot, CONVERTS is more correlated with NVDA than with BTC on 39.6% of days (PURE 3.4%). DCC(1,1): CONVERTS–NVDA 0.334 → 0.418, CONVERTS–BTC 0.501 → 0.477; rmgarch paths correlated ≥ 0.9996 with the Python implementation.

**Questions.**
- *Why DCC in addition to rolling correlation?* Rolling correlation depends on the window length; DCC models the correlation's dynamics from the data and accounts for each series' volatility.
- *Pre-pivot crossings in 2022?* A bear market where everything was correlated with NVDA, PURE included; that is why the control matters.

## 9. LLM section (`llm/`) — to complete after your LLM work

Protocol: code-generated numbers-only summary, 4 prompts (hypotheses / committee explanation / simulated recommendations with limits / self-check), interpretation written **before** the LLM, comparison grid with error types H/C/S/D/M/O, checklist of project-specific errors.

**Questions.**
- *How did you make sure the LLM didn't invent numbers?* It received only `stats_summary.md`; every claim was checked against it (`comparison.md`).
- *Why write your interpretation first?* Otherwise the "comparison" is contaminated by what the LLM said.
- *[Add 1–2 concrete errors the LLM made, from your `comparison.md`.]*

## 10. Limits to state before the examiner does

Short post-pivot sample (447 days); pivot p-values optimistic; borderline CONVERTS–NVDA cointegration; Cholesky order and BTC close timing; three-stock indices; one 123-day test regime; transaction costs not modelled; LLM section depends on one model version at one date.

## 11. Reproducibility (if asked to run it)

`python -m pytest tests -q` (7 passed) → notebooks/python 01–07 → each Rmd after its Python notebook → `python llm/make_stats_summary.py` → `python report/build/report_content.py` + `node report/build/build_docx.js`. Seed 42, PyTorch deterministic, raw data frozen. See `report/REQUIREMENTS_CHECKLIST.md`.
