# Requirements checklist (brief sections 1 to 8)

Status: ✅ done · 🟡 partial · ❌ missing · ⏳ waiting for the student. Last check: 2026-11-17.

## §1 Theme and data

| Requirement | Status | Where |
|---|---|---|
| Theme chosen and justified in one sentence in the introduction | ✅ | report §1.1 |
| Option A: basket of 2–3 correlated assets | ✅ (4 modelled series, explained) | report §1.1, `config.yaml` |
| Daily frequency, ≥ 5 years of data | 🟡 4.88 years, justified (shell companies before 2021-12-14, IREN IPO) | `data/DATA_DICTIONARY.md`, report §2 |
| Download via yfinance / quantmod | ✅ | `src/data.py`, notebook 01 |
| At least one derived indicator | ✅ log return, rv20, ma20, ma50 | notebook 01, `DATA_DICTIONARY.md` |
| §1.3 Native time-series object with declared frequency | ✅ pandas `CustomBusinessDay`; R `xts` | notebook 01, `R/load_data.R` |
| §1.3 Chronological 90/10 split | ✅ | `config.yaml`, notebook 02 §7 |
| §1.3 Source, period and provider adjustments documented | ✅ | `DATA_DICTIONARY.md`, report §2 |

## §2 Exploratory analysis

| Requirement | Status | Where |
|---|---|---|
| Plots: trend, seasonality, breaks, scales | ✅ | `fig_02_01`–`fig_02_04` |
| ACF/PACF raw and differenced, written interpretation | ✅ | notebook 02 §2, `fig_02_05`, `fig_02_06` |
| Decomposition, each component commented | ✅ STL s = 5 and 252 | notebook 02 §3, `02_stl_seasonality.csv` |
| Outliers detected, justified treatment | ✅ Hampel + rolling IQR, kept | `02_outliers.csv`, notebook 02 §4 |
| ADF and KPSS, explicit order of differencing | ✅ d = 1 | `02_stationarity_adf_kpss.csv`, `02_integration_order.csv` |

## §3 Classical modelling (each model with full residual diagnostics)

| Requirement | Status | Where |
|---|---|---|
| ARIMA orders from ACF/PACF + automatic search, compared | ✅ Python + R | notebook 03 §1–2, `03_arima.Rmd` |
| SARIMA if seasonal | ✅ tested, rejected with evidence | notebook 03 §3, `03_seasonal_tests*.csv` |
| Ljung-Box, normality (JB / SW), ARCH test | ✅ | `03_residual_diagnostics*.csv` |
| VAR on ≥ 2 variables, order by AIC/BIC | ✅ | notebook 04 §1, `04_var_lag_selection.csv` |
| Granger causality, interpreted | ✅ | `04_granger.csv` |
| Cointegration (Johansen / Engle-Granger) | ✅ | `04_cointegration.csv` |
| VECM and error-correction term (speed of adjustment) | ✅ half-life | `04_vecm.csv` |
| ARCH-LM on best ARIMA/VAR residuals | ✅ | `05_archlm.csv` |
| GARCH(1,1), higher orders if justified | ✅ (GARCH(2,1) not justified, stated) | notebook 05 §2 |
| Standardised residual diagnostics | ✅ | `05_std_resid_diagnostics.csv` |
| Conditional volatility vs known events | ✅ 6 events, press sources | `fig_05_02`, notebook 05 §4 |

## §4 Advanced modelling

| Requirement | Status | Where |
|---|---|---|
| LSTM and GRU, sliding windows, scaling | ✅ | notebook 06 §1–2 |
| Justified hyperparameters, train/validation loss curves | ✅ | notebook 06 §2–3, `fig_06_01` |
| Time-series cross-validation (walk-forward, no k-fold) | ✅ 5 expanding folds | `06_walk_forward_*.csv` |
| §4.2 Hybrid (optional, valued) | ✅ ARIMA + LSTM | notebook 06 §5 |
| §4.3 Additional models (Prophet, N-BEATS, TFT…) | ❌ not done (bonus; Prophet skipped because there is no seasonality, stated) | notebook 06 header |

## §5 Generative AI and LLMs (4 points)

| Requirement | Status | Where |
|---|---|---|
| Model hypotheses from descriptive stats, prompt + full answer documented | ⏳ prompt ready; answer to obtain | `llm/prompts.md` (a), `llm/answers/` |
| Plain-language explanation for a decision-maker, in appendix | ⏳ prompt ready | `llm/prompts.md` (b) |
| Simulated recommendations with limits stated by the LLM, then completed critically | ⏳ prompt ready, forward forecasts computed | `llm/prompts.md` (c), `results/08_forward_forecasts.csv` |
| Own interpretation written BEFORE, compared with the LLM | ⏳ templates + error checklist ready | `llm/my_interpretation_TEMPLATE.md`, `llm/comparison_TEMPLATE.md`, `llm/CHECKLIST_LLM_ERRORS.md` |

## §6 Forecasting and evaluation

| Requirement | Status | Where |
|---|---|---|
| h = 5 to 10 for every model, with intervals when possible | ✅ | `results/forecasts_*.csv` |
| MSE, RMSE, MAE, MAPE in ONE summary table | ✅ | `results/model_comparison.csv`, `fig_07_01` |
| Diebold-Mariano significance test | ✅ HLN, unit-tested vs R | `src/metrics.py`, `tests/test_metrics.py`, `07_dm_tests.csv` |
| Explicit best model (performance, interpretability, compute cost) | ✅ | notebook 07 §4, report §7 |

## §7 Extensions (bonus)

| Requirement | Status | Where |
|---|---|---|
| Exogenous variables (news, sentiment) | 🟡 BTC/NVDA/volatility as exogenous inputs; no text sentiment | notebook 06 |
| Event detection with text embeddings (FinBERT) | ❌ not done | — |
| Dynamic correlation (rolling, DCC-GARCH) | ✅ Python + rmgarch check | `fig_07_03`, `fig_07_04`, `07_dcc_*.csv` |

## §8 Deliverables

| Requirement | Status | Where |
|---|---|---|
| §8.1 R AND Python for the classical block (§3) | ✅ ARIMA, VAR/VECM, GARCH in both, compared | `notebooks/r/*.Rmd`, `results/*_r_vs_python.csv` |
| §8.1 §4 and extensions in one language, clearly labelled | ✅ "Python only" headers | notebooks 06, 07 |
| §8.1 Every code block commented with a one-line justification | ✅ | all notebooks |
| §8.2 Report (Word/PDF), 15–25 pages, logical order | 🟡 22-page draft; 31 `[TO REVIEW]` paragraphs to rewrite; section 9 and appendix B to write | `report/report.docx`, `report/report.pdf` |
| §8.2 Detailed model comparison table (metrics, complexity, interpretability) | ✅ | report §7 |
| §8.2 Contribution of LLMs (time, clarity, limits) | ⏳ | report §9.5 |
| §8.3 Executable notebook, runs on a clean machine | ✅ verified in a fresh venv on a clean copy | see "Reproducibility check" below |
| §8.4 Critical discussion: model limits + reflection on generative AI | 🟡 limits written; AI reflection is a starting paragraph to rewrite after §5 | report §10 |

## Reproducibility check

Run on 2026-11-17: clean copy of the project (no `.venv`, `results/` and `figures/` emptied), new virtual environment `py -3.11 -m venv` + `pip install -r requirements.txt` (Python 3.11.9), then everything top to bottom.

| Step | Result |
|---|---|
| `pip install -r requirements.txt` | ✅ exit 0 (≈ 7 min, includes CPU PyTorch) |
| Python notebooks 01 → 07 (`jupyter nbconvert --execute`) | ✅ all exit 0 (01: 17 s, 02: 203 s, 03: 73 s, 04: 13 s, 05: 15 s, 06: 60 s, 07: 80 s) |
| `python -m pytest tests -q` | ✅ 7 passed |
| `python llm/make_stats_summary.py` | ✅ |
| R notebooks 01, 03, 04, 05, 07_dcc (`rmarkdown::render`, R 4.6.2) | ✅ all exit 0 |
| Regenerated CSVs vs the project's (73 files, numbers to 1e-6 relative) | ✅ identical, except the measured training times (`06_grid.csv[seconds]`, `model_comparison.csv[training time (s)]`, ≤ 0.5 s), which are wall-clock measures and are expected to vary |

Failures: **none**. Requirement: run each R notebook after its Python notebook (it reads the Python results); R packages from `R/install_packages.R`.

## Open points

- **Deadline**: the brief says 12 October 2026, 23:55 (email to the instructor); the data end on 2026-10-31. Confirm the real date with the instructor.
- **Language**: the report is in English, the brief is in French and does not impose a language. Worth confirming.
